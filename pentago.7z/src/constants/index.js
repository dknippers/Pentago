export const AMOUNT_IN_LINE_TO_WIN = 5;
export const BOARD_SIZE = 6;
export const QUADRANT_SIZE = 3;
export const NUM_QUADRANTS = parseInt(BOARD_SIZE / QUADRANT_SIZE, 10);