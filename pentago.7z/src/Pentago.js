import React from 'react';
import Game from './components/Game';
import DevTools from './components/DevTools';

const Pentago = () => (
  <div>
    <Game />
    {
       // <DevTools />
    }
  </div>
)

export default Pentago;